# NIFTY AI Stock Prediction Dashboard

A comprehensive, fully offline-capable AI stock prediction dashboard featuring both a Streamlit frontend and a Flask/Vanilla-JS frontend.

## Features
- **Offline Data Fetching**: Utilizes a local SQLite cache (`nifty_history.db`) to ensure 100% offline stability without requiring any external internet or Yahoo Finance API connections.
- **Dual Frontends**: 
  - Rich **Streamlit Dashboard** (`app.py`) for complete data visualization and interactive analysis.
  - **Static Web Frontend** (`index.html` + `script.js`) backed by a Flask API (`api.py`) for alternative deployment.
- **Multiple Predictor Models**: Integrates advanced AI/ML algorithms like LSTM, GRU, along with mathematically smoothed fallbacks (ARIMA & Prophet surrogates) through Keras and Scikit-learn.
- **Robust Metrics Analyser**: Computes real-time signals, RSI, Volatilities, and provides an algorithmic recommendation summary text block.
- **No Runtime Dependency Issues**: Solved all `fillna` and `NaN` propagation TypeError bugs to ensure fluid graph plotting and execution.

## Getting Started

### Using Streamlit (Recommended)
You can directly run the Streamlit frontend. It requires no API to be spawned separately as it imports backend logic directly.
```bash
python -m streamlit run app.py
```

### Using Flask API + Web Frontend
Start the local API engine on port 5000:
```bash
python api.py
```
Open `index.html` in your browser. It will fetch realtime stats from the locally running Flask server.

## Architecture
- `data_fetch.py`: Disconnects from live APIs and uses standard fallback logic / db mocking.
- `analysis.py`: Contains technical indicator computation logic without triggering `pandas` TypeError exceptions.
- `model.py`: Handles transparent `train_or_load` model pipelines locally cacheable via `.keras` and `.pkl` formats.
